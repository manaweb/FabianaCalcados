<?php include "topo.php"; ?>
	<div class="section quem-somos" id="corpoTopo">
        <div class="container">
          <div class="row">
            <div class="fundo-title">
              <h3 class="title-section col-lg-12">Quem Somos</h3>
            </div>
          </div>
          <div class="row">
          	<div class="texto-empresa">
				<?php 
					$sql = "select * from historico limit 1";
					$dados = mysql_fetch_assoc(mysql_query($sql));
					echo utf8_encode($dados['texto'])
				?>
			</div>
          </div>
          <div class="row text-center">
      		<img src="img/fabiana.png" alt="Fabiana Calçados" />
      		<img src="img/logo.jpg" alt="Fabiana Calçados" />
          </div>
        </div> <!-- /container -->
      </div> <!-- /section destaque -->
<?php include "scripts.php"; ?>
<?php include "rodape.php" ?>