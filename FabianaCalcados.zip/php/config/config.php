<?php

@include 'php/classes/header.class.php';
@include 'php/functions/functions.php';

session_start();

define('DB_SERVIDOR','127.0.0.1');
define('DB_USUARIO','root');
define('DB_SENHA','');
define('DB_BANCO','fabiana');
define('CONF_EMAIL', '');

define ('DOMAIN','http://higvac.net/101fm/');
define ('CSS_DIRECTORY',DOMAIN.'css/');
define ('JS_DIRECTORY',DOMAIN.'js/');
define ('IMG_DIRECTORY',DOMAIN.'img/');
