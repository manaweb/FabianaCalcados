
</div>

			</div>
			<?php
				if(!isset($page) || $page != 'index'){?>
					<script>
						$(function(){
							$("html, body").animate({scrollTop: '900px'},500);
						})
					</script>

			<?php } ?>

			<div id="rodape" class="rodape clear">
				<div id="rodapeConteudo" class="conteudo">
					<div id="rodapeEsquerda" class="bannerEsquerda rodapeEsquerda">
						<p>	FAQ (Perguntas frequentes)
							<br>
							Chat Online
						</p>
						<p>
							E-mail:<br>
							Contato: <a href="mailto:rfcasaecia@hotmail.com">rfcasaecia@hotmail.com</a>
						</p>
						<p>
							Help desk (Chamados)<br>
							Fone: (16) 3203 9913
						</p>
						<p>
							Horário de Atendimento: de segunda a sexta-feira das 09h00 min às 18h00 min<br />
							S�bado das 9h00 �s13h00
						</p>
					</div>
					<div id="rodapeDireita" class="bannerDireita rodapeDireita">
						<ul>
							<li><a href="index.php">HOME</a> | </li>
							<li><a href="empresa.php">EMPRESA</a> | </li>
							<li><a href="produtos.php">PRODUTOS</a> | </li>
							<li><a href="contato.php">FALE CONOSCO</a></li>
						</ul>
						<span class="destaque">Gostou? Então compartilhe:</span>
						<div class="compartilhe">
							<a href="javascript:void(0);" class="rodapeIcone twitter" title="Nos siga!"></a>
							<a href="javascript:void(0);" class="rodapeIcone facebook" title="Curta nossa página!"></a>
						</div>
						<div id="logoMana" class="clear">
							<a href="http://manaweb.com.br" class="manalogo" title="Maná WEB"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>