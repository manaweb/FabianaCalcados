<? 
	include('../includes/Topo.php');
?>
<?
include('../includes/Mensagem.php');
$ondeestou = 'Acesso Restrito';
?>
<div id="conteudo">

	<p style="color:red;">Acesso restrito: Você não tem permissão para acessar esta área.</p>

</div>
<? include('../includes/Rodape.php'); ?>