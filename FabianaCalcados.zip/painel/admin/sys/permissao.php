<?php header("Content-Type: text/html; charset=UTF-8",true) ?>
<? 
echo "<script>alert('Este site é apenas uma demonstração, você não pode alterar o conteúdo. Obrigado.');</script>";
echo "<script>history.go(-1);</script>";
?>