<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/jquery.blockUI.js"></script>
<script src="js/plugins.js"></script>
<script src="js/main.js"></script>
<script>
<?php 
	if (!isset($page) || $page != "index"){
		echo "
		$(function(){
			scrollToID('#corpoTodo',100);
		})\n";
	}
?>
</script>